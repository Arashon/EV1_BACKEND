from django.shortcuts import render
from django.http import HttpResponse


def vistaMenu(request):
    vista= """
           <h1>
           Seleccione una opción</h1>       
           <ul>
                <li><a href="http://127.0.0.1:8000/optionApp/Tabla/">Tabla</a></li>
                <li><a href="http://127.0.0.1:8000/optionApp/Loteria/">Loteria</a></li>
            </ul> 
    """
    return HttpResponse(vista)

