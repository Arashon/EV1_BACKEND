from django.shortcuts import render

from django.http import HttpResponse

import random 


def vistaTabla(request):
    vista= """
        <h1>Mis paises Favoritos</h1>
        <table class="default">

        <tr>

            <th>Pais</th>

            <th>Continente</th>

            <th>Bandera</th>

        </tr>

        <tr>

            <td>Noruega</td>

            <td>Europa</td>

            <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrDNrZxYC_FUp8i6vNVqJFSj7OSmwuoAI4oGg6jHSaSKsbae4jVdMgWomGjHw&s=10" width="60" height="60" /></td>

        </tr>

        <tr>

            <td>Dinamarca</td>

            <td>Europa</td>

            <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRssxwus4SzCfJgNjmy3KUSQXLLcbYhTlUhCGzBAvkyTxCEIMMR9_qrVAL-CGM7&s=10" width="60" height="60" /></td>

        </tr>

        <tr>

            <td>Canada</td>

            <td>America del norte</td>

            <td> <img src="https://upload.wikimedia.org/wikipedia/commons/d/d9/Flag_of_Canada_%28Pantone%29.svg" width="60" height="60" /></td>

        </tr>

        </table>

        <a href="http://127.0.0.1:8000/menuApp/Inicio/">Inicio</a>
    
    
    """

    return HttpResponse(vista)

def vistaLoteria(request):
    Numeros= [random.randint(1, 100) for _ in range(10)]

    titulo="""<h1>Estos son los números de la suerte en este momento</h1>"""
    random_1=(f"""
        <li><a>{Numeros[1]}</a></li>
        <li><a>{Numeros[2]}</a></li>
        <li><a>{Numeros[3]}</a></li>
        <li><a>{Numeros[4]}</a></li>
        <li><a>{Numeros[5]}</a></li>
        <li><a>{Numeros[6]}</a></li>
        <li><a>{Numeros[7]}</a></li>
        <li><a>{Numeros[8]}</a></li>
        <li><a>{Numeros[9]}</a></li>
        <li><a>{Numeros[0]}</a></li>

        <a href="http://127.0.0.1:8000/menuApp/Inicio/">Inicio</a>
        """)
    




    final=titulo+random_1



    return HttpResponse(final)